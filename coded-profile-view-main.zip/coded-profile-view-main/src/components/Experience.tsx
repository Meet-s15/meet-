
import React from 'react';
import { Calendar, MapPin, Building } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: 'Senior Full Stack Developer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      period: '2022 - Present',
      description: 'Lead development of enterprise applications using React, Node.js, and AWS. Mentored junior developers and improved team productivity by 40%.',
      achievements: [
        'Built scalable microservices architecture serving 100K+ users',
        'Reduced application load time by 60% through optimization',
        'Led team of 5 developers on multiple high-impact projects'
      ]
    },
    {
      title: 'Full Stack Developer',
      company: 'Digital Innovations Inc.',
      location: 'New York, NY',
      period: '2020 - 2022',
      description: 'Developed and maintained web applications using modern JavaScript frameworks. Collaborated with design teams to create exceptional user experiences.',
      achievements: [
        'Delivered 15+ client projects on time and within budget',
        'Implemented automated testing reducing bugs by 50%',
        'Introduced modern development practices and tools'
      ]
    },
    {
      title: 'Frontend Developer',
      company: 'StartupXYZ',
      location: 'Austin, TX',
      period: '2019 - 2020',
      description: 'Focused on creating responsive, accessible web interfaces. Worked closely with UX designers to translate mockups into pixel-perfect implementations.',
      achievements: [
        'Improved website performance scores by 80%',
        'Built reusable component library used across products',
        'Increased user engagement by 35% through UI improvements'
      ]
    },
    {
      title: 'Junior Web Developer',
      company: 'WebDev Agency',
      location: 'Remote',
      period: '2018 - 2019',
      description: 'Started my professional journey building websites for small businesses. Gained experience in various web technologies and client communication.',
      achievements: [
        'Completed 20+ client websites',
        'Learned multiple programming languages and frameworks',
        'Established foundation in web development best practices'
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Work <span className="text-blue-400">Experience</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              My professional journey and the impact I've made at various organizations.
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-gradient-to-b from-blue-500 to-purple-500"></div>

            {experiences.map((experience, index) => (
              <div 
                key={experience.title}
                className={`relative mb-12 ${
                  index % 2 === 0 ? 'md:pr-1/2 md:text-right' : 'md:pl-1/2 md:ml-auto'
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full border-4 border-slate-900 z-10"></div>

                <div className={`ml-8 md:ml-0 ${index % 2 === 0 ? 'md:mr-8' : 'md:ml-8'}`}>
                  <div className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105">
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white mb-1">{experience.title}</h3>
                        <div className="flex items-center text-blue-400 mb-2">
                          <Building size={16} className="mr-2" />
                          <span className="font-semibold">{experience.company}</span>
                        </div>
                      </div>
                      <div className="flex flex-col md:items-end text-sm text-gray-400">
                        <div className="flex items-center mb-1">
                          <Calendar size={14} className="mr-1" />
                          <span>{experience.period}</span>
                        </div>
                        <div className="flex items-center">
                          <MapPin size={14} className="mr-1" />
                          <span>{experience.location}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-gray-300 mb-4">{experience.description}</p>

                    <div className="space-y-2">
                      <h4 className="text-white font-semibold mb-2">Key Achievements:</h4>
                      <ul className="space-y-1">
                        {experience.achievements.map((achievement, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start">
                            <span className="text-blue-400 mr-2">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
