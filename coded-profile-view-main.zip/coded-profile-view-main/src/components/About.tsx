
import React from 'react';
import { Code, Palette, Globe, Database, BookOpen, Zap } from 'lucide-react';

const About = () => {
  const skills = [
    { icon: Code, name: 'HTML & CSS', description: 'Building responsive websites' },
    { icon: Database, name: 'Java Programming', description: 'Object-oriented programming' },
    { icon: Globe, name: 'Python', description: 'Data structures & algorithms' },
    { icon: Palette, name: 'WordPress', description: 'Content management systems' },
    { icon: BookOpen, name: 'Computer Science', description: 'Core CS fundamentals' },
    { icon: Zap, name: 'Problem Solving', description: 'Logical thinking & analysis' },
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-blue-400">Me</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              I'm a passionate Computer Science Engineering student in my 2nd year, 
              based in Bhavnagar, India. I love creating websites and learning new technologies.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <h3 className="text-2xl font-bold text-white mb-4">My Journey</h3>
                <p className="text-gray-300 mb-4">
                  Currently pursuing my Computer Science Engineering degree, I'm passionate about 
                  frontend development and creating beautiful, functional websites. I believe in 
                  continuous learning and staying updated with the latest web technologies.
                </p>
                <p className="text-gray-300">
                  When I'm not coding, you can find me exploring new programming concepts, 
                  working on personal projects, or learning about the latest trends in web development.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-500/20 to-transparent backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <h4 className="text-3xl font-bold text-blue-400 mb-2">2nd</h4>
                <p className="text-gray-300">Year CSE Student</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/20 to-transparent backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <h4 className="text-3xl font-bold text-purple-400 mb-2">6+</h4>
                <p className="text-gray-300">Technologies</p>
              </div>
              <div className="bg-gradient-to-br from-green-500/20 to-transparent backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <h4 className="text-3xl font-bold text-green-400 mb-2">India</h4>
                <p className="text-gray-300">Bhavnagar</p>
              </div>
              <div className="bg-gradient-to-br from-yellow-500/20 to-transparent backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <h4 className="text-3xl font-bold text-yellow-400 mb-2">Fresh</h4>
                <p className="text-gray-300">Eager to Learn</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-3xl font-bold text-white mb-8 text-center">Skills & Technologies</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skills.map((skill, index) => (
                <div 
                  key={skill.name}
                  className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105 group"
                >
                  <skill.icon className="w-12 h-12 text-blue-400 mb-4 group-hover:scale-110 transition-transform duration-300" />
                  <h4 className="text-xl font-semibold text-white mb-2">{skill.name}</h4>
                  <p className="text-gray-400">{skill.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
