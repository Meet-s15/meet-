
import React from 'react';
import { ExternalLink, Github, Eye } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'Personal Portfolio Website',
      description: 'A responsive portfolio website built with HTML, CSS, and modern design principles. Features smooth animations and mobile-first approach.',
      image: '/placeholder.svg',
      technologies: ['HTML', 'CSS', 'JavaScript', 'Responsive Design'],
      liveUrl: '#',
      githubUrl: '#',
      featured: true
    },
    {
      title: 'WordPress Blog Site',
      description: 'A custom WordPress theme developed for a blog website with clean design and user-friendly interface.',
      image: '/placeholder.svg',
      technologies: ['WordPress', 'PHP', 'CSS', 'MySQL'],
      liveUrl: '#',
      githubUrl: '#',
      featured: true
    },
    {
      title: 'Java Calculator',
      description: 'A desktop calculator application built with Java Swing, featuring basic arithmetic operations and clean UI.',
      image: '/placeholder.svg',
      technologies: ['Java', 'Swing', 'OOP'],
      liveUrl: '#',
      githubUrl: '#',
      featured: false
    },
    {
      title: 'Python To-Do App',
      description: 'A simple command-line to-do application built with Python, demonstrating file handling and data structures.',
      image: '/placeholder.svg',
      technologies: ['Python', 'File I/O', 'Data Structures'],
      liveUrl: '#',
      githubUrl: '#',
      featured: false
    },
    {
      title: 'CSS Animation Showcase',
      description: 'A collection of creative CSS animations and effects demonstrating advanced styling techniques.',
      image: '/placeholder.svg',
      technologies: ['HTML', 'CSS', 'Animations', 'Flexbox'],
      liveUrl: '#',
      githubUrl: '#',
      featured: false
    },
    {
      title: 'Responsive Landing Page',
      description: 'A modern, responsive landing page template built with HTML and CSS, optimized for all devices.',
      image: '/placeholder.svg',
      technologies: ['HTML', 'CSS', 'Responsive', 'Mobile-First'],
      liveUrl: '#',
      githubUrl: '#',
      featured: false
    }
  ];

  const featuredProjects = projects.filter(project => project.featured);
  const otherProjects = projects.filter(project => !project.featured);

  return (
    <section id="projects" className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              My <span className="text-blue-400">Projects</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Here are some projects I've worked on during my learning journey as a Computer Science student.
            </p>
          </div>

          {/* Featured Projects */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-white mb-8">Featured Projects</h3>
            <div className="grid md:grid-cols-2 gap-8">
              {featuredProjects.map((project, index) => (
                <div 
                  key={project.title}
                  className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/10 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105 group"
                >
                  <div className="relative overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-3">{project.title}</h4>
                    <p className="text-gray-300 mb-4">{project.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech) => (
                        <span 
                          key={tech}
                          className="px-3 py-1 text-sm bg-blue-500/20 text-blue-300 rounded-full border border-blue-500/30"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex space-x-4">
                      <a 
                        href={project.liveUrl}
                        className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors duration-200"
                      >
                        <ExternalLink size={16} />
                        <span>Live Demo</span>
                      </a>
                      <a 
                        href={project.githubUrl}
                        className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200"
                      >
                        <Github size={16} />
                        <span>Code</span>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Other Projects */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-8">Other Projects</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherProjects.map((project, index) => (
                <div 
                  key={project.title}
                  className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105 group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h4 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors duration-200">
                      {project.title}
                    </h4>
                    <div className="flex space-x-2">
                      <a 
                        href={project.liveUrl}
                        className="text-gray-400 hover:text-blue-400 transition-colors duration-200"
                      >
                        <Eye size={16} />
                      </a>
                      <a 
                        href={project.githubUrl}
                        className="text-gray-400 hover:text-white transition-colors duration-200"
                      >
                        <Github size={16} />
                      </a>
                    </div>
                  </div>
                  
                  <p className="text-gray-300 mb-4 text-sm">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-1">
                    {project.technologies.map((tech) => (
                      <span 
                        key={tech}
                        className="px-2 py-1 text-xs bg-blue-500/20 text-blue-300 rounded border border-blue-500/30"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
